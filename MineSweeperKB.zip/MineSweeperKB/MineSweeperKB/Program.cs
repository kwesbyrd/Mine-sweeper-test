﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MineSweeperKB
{
    class MineSweeper
    {
        // checks to see if a cell in an array is inbounds
        public static bool CellInbound(string[,] array, int x, int y)
        {
            if (x < array.GetLowerBound(0) || x > array.GetUpperBound(0) || y < array.GetLowerBound(1) || y > array.GetUpperBound(1))
                return false;

            return true;
        }
       

        static void Main(string[] args)
        {
            // rows ,columns and numMines can be altered to any integer
            int rows = 5;
            int columns = 5;
            int numMines = 3;
            string mine = "x";
            int adjMines =0 ;
           
            //create the minesweeper board
            string[,] mineField = new string[rows,columns];
           
            // intialize random grid coordinate generator
            Random rnd1 = new Random();


         
        //This is the main function that lays the mines. Used a do-while loop to ensure all lines are layed and 2 for loops to iterate 
        //over each cell in the minefield

            do {
                for (int rowz = 0; rowz < mineField.GetLength(0); rowz++)
                {
                    for (int colz = 0; colz < mineField.GetLength(1); colz++)
                    {
                        //generate a set of random coordinates on the minefield
                            var randRows = rnd1.Next(rows);
                            var randCols = rnd1.Next(columns);
                        
                        //If the current array coordinates match the randomly generated coordinates
                        //and there is not a mine already there, place a mine and deduct it from the total mines
                            if ((randRows == rowz) && (randCols == colz)&&(mineField[rowz,colz]!=mine))
                            {
                                mineField[rowz, colz] = mine;
                                numMines--;
                            }  
                    }
                    
                }
            } while (numMines > 0);

         

            //clue function checks the surrounding squares and for mines and populates a clue based on the mines present
            for (int rz = 0; rz < mineField.GetLength(0); rz++)
                {
                    for (int cz = 0; cz < mineField.GetLength(1); cz++)
                    {   
                    //first make sure a mine is not already there
                        if (mineField[rz, cz] != mine)
                        {
                            if ((CellInbound(mineField, rz - 1, cz) == true) && (mineField[rz - 1, cz] == mine))
                            {
                                adjMines++;
                            }
                            if ((CellInbound(mineField, rz, cz - 1) == true) && (mineField[rz, cz - 1] == mine))
                            {
                                adjMines++;
                            }
                            if ((CellInbound(mineField, rz - 1, cz - 1) == true) && (mineField[rz - 1, cz - 1] == mine))
                            {
                                adjMines++;
                            }
                            if ((CellInbound(mineField, rz + 1, cz) == true) && (mineField[rz + 1, cz] == mine))
                            {
                                adjMines++;
                            }
                            if ((CellInbound(mineField, rz, cz + 1) == true) && (mineField[rz, cz + 1] == mine))
                            {
                                adjMines++;
                            }
                            if ((CellInbound(mineField, rz + 1, cz + 1) == true) && (mineField[rz + 1, cz + 1] == mine))
                            {
                                adjMines++;
                            }
                            if ((CellInbound(mineField, rz + 1, cz - 1) == true) && (mineField[rz + 1, cz - 1] == mine))
                            {
                                adjMines++;
                            }
                            if ((CellInbound(mineField, rz - 1, cz + 1) == true) && (mineField[rz - 1, cz + 1] == mine))
                            {
                                adjMines++;
                            }// last if statment to place the clue
                            if (adjMines == 0)
                            {
                            mineField[rz, cz] = " ";
                            }
                                else
                                 {
                                    mineField[rz, cz] = adjMines.ToString();

                                    adjMines = 0;
                                   }
                            
                        }
                    }
                }

            //display the minefield      
            for (int r = 0; r < mineField.GetLength(0); r++)
            {
                for (int c = 0; c < mineField.GetLength(1); c++)
                {
                    Console.Write("\t{0}", mineField[r, c]);
                }
                Console.WriteLine();
            }

            Console.ReadLine();


        

                  
                    
        }
    }
}
